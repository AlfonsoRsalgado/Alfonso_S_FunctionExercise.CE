let multiply = {
    (val1:  Int, val2: Int) -> Int in
    return val1 * val2
}

let results = multiply(21, 100)
print (results)
